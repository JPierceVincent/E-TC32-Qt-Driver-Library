/************************************************************************************************
 * File:			mccqethernet.h
 * Author:			Joseph Vincent
 * Email:			josephpiercevincent@gmail.com
 * Github:          https://github.com/JPierceVincent
 * Based On:        E-TC32 Driver
 * Author:          Warren J. Jasper
 * Email:           wjasper@ncsu.edu
 * Github:          https://github.com/wjasper
 *
 * Create Date:		February 2nd, 2021, 15:57 PM
 * Module Name:		Main Window
 * Target Devices:	Windows 10 or Linux
 * Tool versions:	Qt 5.13.0
 * Complier:		MinGW 4.8 32bit
 * Description:		This is the header file for a port of the E-TC32 C Driver
 *                  developed by Warren J. Jasper and housed at the following repo:
 *                  https://github.com/org-arl/MCC_Linux_Drivers/blob/master/Ethernet/c/E-TC32.h
 *                  it intends to open a previous linux-only driver to multi-platform support
 *                  along with leveraging some object oriented approaches which adds additional
 *                  functionality via the movement from C -> C++
 *~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*/

#ifndef MCCQETHERNET_H
#define MCCQETHERNET_H

#include <QUdpSocket>
#include <QTcpSocket>
#include <QTimer>
#include "time.h"
#include <string>

#define DISCOVER_PORT   54211
#define COMMAND_PORT    54211
#define SCAN_PORT       54212

#define MSG_SUCCESS         0   // Command succeeded
#define MSG_ERROR_PROTOCOL  1   // Command failed due to improper protocol
                                // (number of expected data bytes did not match protocol definition)
#define MSG_ERROR_PARAMETER 2   // Command failed due to invalid parameters
                                // (the data contents were incorrect)
#define MSG_ERROR_BUSY      3   // Command failed because resource was busy
#define MSG_ERROR_READY     4   // Command failed because the resource was not ready
#define MSG_ERROR_TIMEOUT   5   // Command failed due to a resource timeout
#define MSG_ERROR_OTHER     6   // Command failed due to some other error

#define MSG_HEADER_SIZE     6
#define MSG_CHECKSUM_SIZE   1

#define MSG_INDEX_START      0
#define MSG_INDEX_COMMAND    1
#define MSG_INDEX_FRAME      2
#define MSG_INDEX_STATUS     3
#define MSG_INDEX_COUNT_LOW  4  // The maximum value for count is 1024
#define MSG_INDEX_COUNT_HIGH 5
#define MSG_INDEX_DATA       6

#define MSG_REPLY            (0x80)
#define MSG_START            (0xDB)

#define ETC32_PID       0x0132

// Digital I/O Commands
#define CMD_DIN            (0x00)  // Read DIO pins
#define CMD_DOUT_R         (0x02)  // Read DIO latch value
#define CMD_DOUT_W         (0x03)  // Write DIO latch value

// Temperature Input Commands
#define CMD_TIN               (0x10)  // Read single thermocouple channel
#define CMD_CJC               (0x11)  // Read single CJC sensor
#define CMD_TIN_MULTIPLE      (0x12)  // Read multiple thermocouple channels
#define CMD_CJC_MULTIPLE      (0x13)  // Read multiple CJC sensors
#define CMD_TIN_CONFIG_R      (0x14)  // Read temperature channel configuration
#define CMD_TIN_CONFIG_W      (0x15)  // Write temperature channel configuration
#define CMD_TIN_STATUS        (0x16)  // Read temperature channel data status
#define CMD_OTD_STATUS        (0x17)  // Read open thermocouple detect data status
#define CMD_MEASURE_CONFIG_R  (0x18)  // Read measurement configuration
#define CMD_MEASURE_CONFIG_W  (0x19)  // Write measurement configuration
#define CMD_MEASURE_MODE_R    (0x1a)  // Read measurement mode
#define CMD_MEASURE_MODE_W    (0x1b)  // Write measurement mode

// Alarm Commands
#define CMD_ALARM_CONFIG_R    (0x20)  // Read alarm configuration
#define CMD_ALARM_CONFIG_W    (0x21)  // Write alarm configuration
#define CMD_ALARM_STATUS_R    (0x22)  // Read temperature alarm status
#define CMD_ALARM_STATUS_W    (0x23)  // Clear temperature alarm status

// Memory Commands
#define CMD_USER_MEMORY_R     (0x30) // Read user memory
#define CMD_USER_MEMORY_W     (0x31) // Write user memory
#define CMD_SETTINGS_MEMORY_R (0x32) // Read network settings memory
#define CMD_SETTINGS_MEMORY_W (0x33) // Write network settings memory
#define CMD_CONFIG_MEMORY_R   (0x34) // Read device configuration memory
#define CMD_CONFIG_MEMORY_W   (0x35) // Write device configuration memory
#define CMD_FACTORY_COEF_R    (0x36) // Read factory calibration coefficients
#define CMD_FACTORY_COEF_W    (0x37) // Write factory calibration coefficients
#define CMD_FIELD_COEF_R      (0x38) // Read field calibration coefficients
#define CMD_FIELD_COEF_W      (0x39) // Write field calibration coefficients
#define CMD_CAL_DATE_R        (0x3a) // Read factory calibration coefficients
#define CMD_CAL_DATE_W        (0x3b) // Write factory calibration coefficients
#define CMD_GAIN_VOLTAGE_R    (0x3c) // Read gain reference voltages
#define CMD_GAIN_VOLTAGE_W    (0x3d) // Write gain reference voltages

// Miscellaneous Commands
#define CMD_BLINK_LED         (0x50) // Blink the LED
#define CMD_RESET             (0x51) // Reset the device
#define CMD_STATUS            (0x52) // Read device status
#define CMD_VERSION           (0x53) // Read firmware versions
#define CMD_NETWORK_CONFIG    (0x54) // Read the current network configuration
#define CMD_AD_CAL            (0x55) // Run the A/D offset calibration

#define BASE                (0x1) // Base unit
#define EXP                 (0x2) // expansion unit

#define UNITS_CELSIUS       (0x0) // read in Celsius
#define VOLTAGE             (0x1) // read in Voltage

#define CHAN_DISABLE 0

//Thermocouple Types
#define TC_TYPE_J    1  // Type J thermocouple
#define TC_TYPE_K    2  // Type K thermocouple
#define TC_TYPE_T    3  // Type T thermocouple
#define TC_TYPE_E    4  // Type E thermocouple
#define TC_TYPE_R    5  // Type R thermocouple
#define TC_TYPE_S    6  // Type S thermocouple
#define TC_TYPE_B    7  // Type B thermocouple
#define TC_TYPE_N    8  // Type N thermocouple

struct version_t {
  uint16_t version_comms;       // the communications micro firmware version
  uint16_t boot_version_comms;  // the communications micro bootloader firmware version
  uint16_t version_base;        // the base measurement micro firmware version
  uint16_t boot_version_base;   // the base measurement micro bootloader firmware version
  uint16_t version_exp;         // the EXP measurement micro firmware version
  uint16_t boot_version_exp;    // the EXP measurement micro firmware version
};

struct networkDeviceInfo_t {
  QString addr;				// QString of Device IP Address
  uint32_t ip_address;      // current device IP address
  uint32_t subnet_mask;     // current device subnet mask
  uint32_t gateway_address; // current gatewayaddress
};

class mccQEthernet : public QObject
{

		Q_OBJECT

public:
	explicit mccQEthernet(QObject *parent = 0);
    ~mccQEthernet();
    version_t version;
    struct tm date_base;
	struct tm date_exp;
    //Active Signals ~ Allow the destructor of mccQEthernet to delete attributes without fear of SegFault
    uint8_t tcpAct, udpAct, timrAct;
	networkDeviceInfo_t netDevInfo;
	//Frame ID for TCP message structure
    uint8_t frameID;
	// the configuration value of each channel (type of thermocouple);
	uint8_t config_values[64];
    //Mask for mult channel cap ([0]0x00000001 will cap chan 1, [0]0x00000013 caps chans 1, 2, 5 ; etc...)
    uint32_t channel_mask[2];
	//Capture values by channel
	float tin_values[64];
	//Units of measurement | Wait till next temp update (0,1) | Channel to capture in the case of a single channel cap
	uint8_t units, wait, channel;
	//Count for LED Blink Test
	uint8_t count;
	//the measurement configuration
	uint8_t config_measure[2];
	// the reading status of the Tin channels
	uint32_t Tin_status[2];
	// 1 - EXP detected, 0 - no EXP detected
	uint16_t status;
	// the status of the open thermocouple detect.
	uint32_t OTD_status[2];
	//Connection code of the TC-32
    uint32_t connectionCode;
	//Event Timer for automated data collection
	QTimer *eventTimer;
    //signifies how the timer should capture (0 = single channel) | (1 = multi channel)
    uint8_t timerOpt;
    uint32_t timeoutInterval;
	//status of connection (-1 Error connecting | 0 - connecting | 1 - connected)
	int devStat = 0;

signals:
    /*******************************************************************************
    * Class:		mccQEthernet
    * Signal:		receivedVal(uint8_t)
    * Description:	This signal is intended as an indicator that a new sample has
    *               been acquired and is ready to be further processed. This is used
    *               in the case of single channel acquisition.
    *******************************************************************************/
	void receivedVal(float);

    /*******************************************************************************
    * Class:		mccQEthernet
    * Signal:		receivedVal(uint8_t)
    * Description:	This signal is intended as an indicator that new samples from
    *               channels defined by the channel_mask[2] configuration have come in.
    *               This signal is emitted in the case that the object is set to acquire
    *               multiple channels.
    *******************************************************************************/
	void receivedVals(float *tin_values);

	void connFin(int);
public slots:
	/*******************************************************************************
	* Class:		mccQEthernet
	* Function:		startPollTimer
	* Description:	This command configures and starts the event timer for automated
	*               capture. A value of 0 for timerOpt attribute will connect the
	*               timer timeout to capture for a single channel. A value of 1 for
	*               the timerOpt attribute will connect the timer timeout to capture
	*               for multiple channels.
	*******************************************************************************/

	void startPollTimer(quint32 timeoutmS, quint8 wait4newSamp, quint8* tcType, quint8 units_type, quint32 capCh_mask);
    /*******************************************************************************
    * Class:		mccQEthernet
    * Function:		openDevice
    * Description:	This function establishes Ethernet communication with
    *               the TC32
    *******************************************************************************/
	int  openDevice(quint32 devID, QString ipAddress);

    /*******************************************************************************
    * Class:		mccQEthernet
    * Function:		BlinkLED_E_TC32
    * Description:	This function Blinks the device power LED a number of times
    *               specified by count
    *******************************************************************************/
	bool BlinkLED_E_TC32();

    /*******************************************************************************
    * Class:		mccQEthernet
    * Function:		Tin_E_TC32
    * Description:	This command reads the value of a single thermocouple channel.
    *               There are some special return values:
    *
    *               -777.0: Input voltage outside valid common-mode voltage range
    *               -888.0: Open thermocouple detected
    *               -999.0: Channel disabled (also returned if EXP channels are
    *                       specified but no EXP is connected)
    *               channel: the channel to read (0-63)
    *               units:   0 - Celsius, linearized by TC type
    *                        1 - Voltage
    *                        2 - ADC code (uncalibrated)
    *               wait:    0 - return current value, 1 - wait for
    *                            new reading before returning
    *******************************************************************************/
	bool Tin_E_TC32();

    /*******************************************************************************
    * Class:		mccQEthernet
    * Function:		TinConfigR_E_TC32
    * Description:	This command reads the thermocouple channel configurations.  Each
    *               configuration is a uint8_t with the following possible values:
    *                    0 - channel disabled
    *                    1 - TC type J
    *                    2 - TC type K
    *                    3 - TC type T
    *                    4 - TC type E
    *                    5 - TC type R
    *                    6 - TC type S
    *                    7 - TC type B
    *                    8 - TC type N
    *******************************************************************************/
	bool TinConfigR_E_TC32();

    /*******************************************************************************
    * Class:		mccQEthernet
    * Function:		TinConfigW_E_TC32
    * Description:	This command writes the thermocouple channel
                    configurations. The micro stores these values in EEPROM and
                    loads them from EEPROM at power on.  Each configuration is a
                    uint8_t with the following possible values:
                        0 - channel disabled
                        1 - TC type J
                        2 - TC type K
                        3 - TC type T
                        4 - TC type E
                        5 - TC type R
                        6 - TC type S
                        7 - TC type B
                        8 - TC type N
    *******************************************************************************/
	bool TinConfigW_E_TC32();

    /*******************************************************************************
    * Class:		mccQEthernet
    * Function:		MeasureConfigW_E_TC32
    * Description:	This command reads the measurement configuration.
                    bit 0: 0 - OTD enable,    1 - OTD disabled
                    bit 1: 0 - notch @ 60 Hz, 1 - notch @ 50 Hz
                    bit 2: 0 - factory coef.  1 - field coef.
    *******************************************************************************/
	bool MeasureConfigW_E_TC32();

    /*******************************************************************************
    * Class:		mccQEthernet
    * Function:		TinMultiple_E_TC32
    * Description:	Ths command reads the value of multiple thermocouple channels.
                    The channels to be read are passed as a bitmap when calling the
                    command.  The data will be returned in the order low channel
                    number to high channel number.  The number of floating point
                    values returned will be equal to the number of channels specified
                    (max 64).  The special return values listed in the TIn command
                    also apply to this command.
                    wait:
                        0 - return current value
                        1 - wait for new reading before returning
                    units:
                        0 - Celsius
                        1 - Voltage
                        2 - ADC code (uncalibraded)
                    channel_mask_base:
                        the channel bitmask for the base unit (channel 0-31)
                    channel_mask_exp:
                        the channel bitmask for the EXP unit (channel 32-63)
    *******************************************************************************/
	bool TinMultiple_E_TC32();

    /*******************************************************************************
    * Class:		mccQEthernet
    * Function:		TinStatus_E_TC32
    * Description:	This command reads the status of the temperature readings.  If
    *               a bit is set the corresponding channel has a new reading that
    *               has not been read with either the Tin or TinMultiple command.
    *******************************************************************************/
	bool TinStatus_E_TC32();

    /*******************************************************************************
    * Class:		mccQEthernet
    * Function:		Status_E_TC32
    * Description:	This command reads the device status.
    *               status: bit 0 - no EXP detected, 1 - EXP detected
    *******************************************************************************/
	bool Status_E_TC32();

    /*******************************************************************************
    * Class:		mccQEthernet
    * Function:		OTDStatus_E_TC32
    * Description:	This command reads the status of the open thermocouple
    *               detection.  If a bit is set an open thermocouple is currently
    *               detected on the corresponding channel.  The LED on the front
    *               of the device is on if any bits are set in this value.
    *******************************************************************************/
	bool OTDStatus_E_TC32();

    /*******************************************************************************
    * Class:		mccQEthernet
    * Function:		Version_E_TC32
    * Description:	This command reads the device firmware versions.  Each version
    *               will be in hex BCD (i.e. 0x0103 is version 1.03)
    *******************************************************************************/
	bool Version_E_TC32();

    /*******************************************************************************
    * Class:		mccQEthernet
    * Function:		CalDateR_E_TC32
    * Description:	This command reads the calibration dates.
    *******************************************************************************/
	bool CalDateR_E_TC32();

    /*******************************************************************************
    * Class:		mccQEthernet
    * Function:		CJC_E_TC32
    * Description:	This command reads the most recent value of a single CJC sensor
    *               in Celsius.  The value -999.0 will be returned if an EXP sensor
    *               is specified bu no EXP is connected.
    *               special return values:
    *                    channel: the channel to read (0-63)
    *******************************************************************************/
	bool CJC_E_TC32(uint8_t channel, float *value);

    /*******************************************************************************
    * Class:		mccQEthernet
    * Function:		NetworkConfig_E_TC32
    * Description:	This command reads the current device network configuration
    *******************************************************************************/
	bool NetworkConfig_E_TC32();

    /*******************************************************************************
    * Class:		mccQEthernet
    * Function:		ADCal_E_TC32
    * Description:	This command causes the measurement loop to pause and an A/D
    *               system offset calibration to run.  The calibration requires
    *               approximately 50ms to complete then the measurement loop
    *               automatically returns to the current mode.  The calibration will
    *               run on all A/Ds on both the main unit and EXP simultaneously.
    *               The command reply will not be sent until the calibration
    *               completes.
    *******************************************************************************/
	bool ADCal_E_TC32();

    /*******************************************************************************
    * Class:		mccQEthernet
    * Function:		SettingsMemoryR_E_TC32
    * Description:	This command reads the nonvolatile network memory. The
    *               settings memory is 32 bytes (address 0 - 0x1F).
    *******************************************************************************/
	bool SettingsMemoryR_E_TC32(uint16_t address, uint16_t count, uint8_t *data);

    /*******************************************************************************
    * Class:		mccQEthernet
    * Function:		SettingsMemoryW_E_TC32
    * Description:	This command writes the nonvolatile settings memory. The settings
    *               memory is 32 bytes (address 0 - 0x1F).  The amount of data to be
    *               written is inferred from the frame count - 2.  The maximum that
    *               can be written is 32 bytes.  The settings will be implemented
    *               after a device reset.
    *******************************************************************************/
	bool SettingsMemoryW_E_TC32( uint16_t address, uint16_t count, uint8_t *data);

private:
    QUdpSocket *udpSocket;
    QTcpSocket *tcpSocket;

    /*******************************************************************************
    * Class:		mccQEthernet
    * Function:		nBits
    * Description:	Counts the number of set bits in a number
    *******************************************************************************/
    int nBits(uint32_t num);

    /*******************************************************************************
    * Class:		mccQEthernet
    * Function:		calcChecksum
    * Description:	This function calculates the checksum and ensures proper
    *               allignment on messages/helps detect errors
    *******************************************************************************/
    char calcChecksum(void *buffer, int length);
};

#endif // MCCQETHERNET_H
