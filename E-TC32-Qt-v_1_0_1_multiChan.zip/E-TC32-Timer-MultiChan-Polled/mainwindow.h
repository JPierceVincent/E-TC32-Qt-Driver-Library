#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include "mccqethernet.h"

namespace Ui {
class MainWindow;
}

#define TC32_CONNECTION_CODE 1064
#define TC32_IP_ADDRESS "10.220.162.69"

class MainWindow : public QMainWindow
{
		Q_OBJECT

	public:

		QThread *tc32thread;
		explicit MainWindow(QWidget *parent = nullptr);
		uint32_t channel_mask;
		uint8_t config_values[64];
		~MainWindow();

	signals :
		void startCapTimer(quint32 timeIntrv, quint8 wait, quint8* tc_type, quint8 units, quint32 chmask); // Timeout interval in mS | Wait for new Sample | ThermoCouple Type | UNITS | Cap Channel mask
		void connectTc32(quint32, QString);

	public slots:
		void updateTempDisp(float *value);
		void TC32_Connection_Finished(int);
	private:
		Ui::MainWindow *ui;
		//QThread *tc32thread;
		mccQEthernet *TC32;

};

#endif // MAINWINDOW_H
