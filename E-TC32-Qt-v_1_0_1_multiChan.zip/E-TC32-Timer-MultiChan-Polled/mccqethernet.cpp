﻿/************************************************************************************************
 * File:			mccqethernet.h
 * Author:			Joseph Vincent
 * Email:			josephpiercevincent@gmail.com
 * Github:          https://github.com/JPierceVincent
 * Based On:        E-TC32 Driver
 * Author:          Warren J. Jasper
 * Email:           wjasper@ncsu.edu
 * Github:          https://github.com/wjasper
 *
 * Create Date:		February 2nd, 2021, 15:57 PM
 * Module Name:		Main Window
 * Target Devices:	Windows 10 or Linux
 * Tool versions:	Qt 5.13.0
 * Complier:		MinGW 4.8 32bit
 * Description:		This is the cpp file for a port of the E-TC32 C Driver
 *                  developed by Warren J. Jasper and housed at the following repo:
 *                  https://github.com/org-arl/MCC_Linux_Drivers/blob/master/Ethernet/c/E-TC32.h
 *                  it intends to open a previous linux-only driver to multi-platform support
 *                  along with leveraging some object oriented approaches which adds additional
 *                  functionality via the movement from C -> C++
 *~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*/
#include "mccqethernet.h"
#include <QThread>


mccQEthernet::mccQEthernet(QObject *parent) : QObject (parent)
{

}

mccQEthernet::~mccQEthernet()
{
    if(udpAct){
        if(udpSocket->isOpen()){
            udpSocket->close();
            delete udpSocket;
        }
    }

    if(tcpAct){
        if(tcpSocket->isOpen()){
            tcpSocket->close();
            delete tcpSocket;
        }
    }

    if (timrAct){
        delete eventTimer;
    }
}

/*******************************************************************************
* Class:		mccQEthernet
* Function:		nBits
* Description:	Counts the number of set bits in a number
*******************************************************************************/
int mccQEthernet::nBits(uint32_t num)
{
  int count = 0;
  int i;

  // counts the number of bits in a number
  for (i = 0; i < 32; i++) {
    if ((num & 0x1) == 0x1) count++;
    num = (num >> 0x1);
  }
  return count;
}

/*******************************************************************************
* Class:		mccQEthernet
* Function:		MeasureConfigW_E_TC32
* Description:	This command reads the measurement configuration.
                bit 0: 0 - OTD enable,    1 - OTD disabled
                bit 1: 0 - notch @ 60 Hz, 1 - notch @ 50 Hz
                bit 2: 0 - factory coef.  1 - field coef.
*******************************************************************************/
bool mccQEthernet::MeasureConfigW_E_TC32()
{

  char buffer[16];
  char replyBuffer[16];
  bool result = false;
  int length;
  int dataCount = 2;
  int replyCount;

  buffer[MSG_INDEX_COMMAND]        = CMD_MEASURE_CONFIG_W;
  buffer[MSG_INDEX_START]          = MSG_START;
  buffer[MSG_INDEX_DATA]           = config_measure[0];
  buffer[MSG_INDEX_DATA+1]         = config_measure[1];
  buffer[MSG_INDEX_FRAME]          = frameID++;  // increment frame ID with every send
  buffer[MSG_INDEX_STATUS]         = 0;
  buffer[MSG_INDEX_COUNT_LOW]      = (unsigned char) (dataCount);
  buffer[MSG_INDEX_COUNT_HIGH]     = (unsigned char) (dataCount >> 8);
  buffer[MSG_INDEX_DATA+dataCount] = (unsigned char) 0xff - calcChecksum(buffer, MSG_INDEX_DATA+dataCount);

  if(tcpSocket->write(buffer, MSG_HEADER_SIZE+MSG_CHECKSUM_SIZE+dataCount) > 0){
    replyCount = 0;

  }
   tcpSocket->waitForReadyRead(5000);
   length = tcpSocket->read(replyBuffer, MSG_HEADER_SIZE+MSG_CHECKSUM_SIZE+replyCount);

   if(length > 0){
     if(length == MSG_HEADER_SIZE+MSG_CHECKSUM_SIZE+replyCount){
         if ((replyBuffer[MSG_INDEX_START] == buffer[0])                                        &&
             (replyBuffer[MSG_INDEX_COMMAND] == (buffer[MSG_INDEX_COMMAND] | (char)MSG_REPLY))  &&
             (replyBuffer[MSG_INDEX_FRAME] == (char)buffer[2])                                  &&
             (replyBuffer[MSG_INDEX_STATUS] == MSG_SUCCESS)                                     &&
			 (replyBuffer[MSG_INDEX_COUNT_LOW] == ( char)replyCount)                            &&
			 (replyBuffer[MSG_INDEX_COUNT_HIGH] == ( char)(replyCount >> 8)))
         {
             result = true;
         }

         if(((unsigned char)replyBuffer[MSG_INDEX_DATA+replyCount] + (unsigned char)calcChecksum(replyBuffer, MSG_HEADER_SIZE+replyCount) != 0xff)) {
           result = false;
         }

     }
   }

  if (result == false) {
	qDebug("Error in MeasureConfigW_E_TC32. Status = %d\n", replyBuffer[MSG_INDEX_STATUS]);
  }
  return result;
}


/*******************************************************************************
* Class:		mccQEthernet
* Function:		openDevice
* Description:	This function establishes Ethernet communication with
*               the TC32
*******************************************************************************/
int mccQEthernet::openDevice(quint32 devID, QString ipAddress)
{

  qDebug("Opening Device! \r\n");

  frameID = 0; // 0 out frameID to start

  char msg[64];
  QByteArray sendDatabuf;
  QByteArray rcvDatabuf;
  quint16 discover_port = DISCOVER_PORT;
  quint16 command_port = COMMAND_PORT;
  int bytesReceived;

  udpAct = 0;
  tcpAct = 0;
  timrAct = 0;

  netDevInfo.addr = ipAddress;
  connectionCode = devID;

  // open the UDP socket
  QHostAddress *host  = new QHostAddress(netDevInfo.addr);
  udpSocket = new QUdpSocket();
  udpAct = 1;
  udpSocket->connectToHost(*host, discover_port);

  if(udpSocket->state() != QAbstractSocket::ConnectedState){
          qDebug("openDevice: error in connect.");
          udpSocket->close();
		  devStat = -1;
		  emit connFin(devStat);
		  return 0;
  }

  msg[0] = 'C';
  memcpy(&msg[1], &connectionCode, 4);

  udpSocket->writeDatagram(msg, 5, *host, discover_port);

  int counter = 0;
   bytesReceived = (udpSocket->readDatagram(msg, 2, host, &discover_port));
   //Block for some time to wait for response
   while(bytesReceived < 0 && counter != 500000){
        counter ++;
        bytesReceived = (udpSocket->readDatagram(msg, 2, host, &discover_port));
   };

  counter = 0;

  if ((bytesReceived == 2) && (msg[0] = 'C') && (msg[1] == 0)) {
	  qDebug("Recvd a good response\r\n");
    }
  else {
    udpSocket->close();
    delete udpSocket;
    udpAct = 0;
    //qDebug("Other Case - bytes received %d Msg: %d %c\r\n", bytesReceived, msg[1], msg[0]);
	devStat = -1;
	emit connFin(devStat);
	return 0;
    }
  udpSocket->close();

  tcpSocket = new QTcpSocket();
  tcpAct = 1;
  tcpSocket->connectToHost(*host, command_port);

  while(tcpSocket->waitForConnected() && tcpSocket->state() != 3 ){//&& counter != 500000){
      if(counter == 50000 || counter == 100000 || counter ==400000){
          qDebug("Current Connection State : %d \r\n", tcpSocket->state() );
      }
      counter ++;
  };

  if(tcpSocket->state() != QAbstractSocket::ConnectedState){

          qDebug("openDevice: error in connect.");
          tcpSocket->close();
		  devStat = -1;
		  emit connFin(devStat);
		  return 0;
  }
  qDebug("TCP Socket Opened \r\n");
  devStat = 1;
  emit connFin(devStat);
  return 0;
}

/*******************************************************************************
* Class:		mccQEthernet
* Function:		calcChecksum
* Description:	This function calculates the checksum and ensures proper
*               allignment on messages/helps detect errors
*******************************************************************************/
char mccQEthernet::calcChecksum(void *buffer, int length)
{
  int i;
  unsigned char checksum = 0;

  for (i = 0; i < length; i++) {
    checksum += ((unsigned char*) buffer)[i];
  }
  return checksum;
}

/*******************************************************************************
* Class:		mccQEthernet
* Function:		BlinkLED_E_TC32
* Description:	This function Blinks the device power LED a number of times
*               specified by count
*******************************************************************************/
bool mccQEthernet::BlinkLED_E_TC32()
{

  char buffer[16];
  char replyBuffer[16];
  bool result = false;
  int length = 0;
  int dataCount = 1;
  int replyCount;

  buffer[MSG_INDEX_COMMAND]        = CMD_BLINK_LED;
  buffer[MSG_INDEX_START]          = MSG_START;
  buffer[MSG_INDEX_DATA]           = count;
  buffer[MSG_INDEX_FRAME]          = frameID++;  // increment frame ID with every send
  buffer[MSG_INDEX_STATUS]         = 0;
  buffer[MSG_INDEX_COUNT_LOW]      = (unsigned char) (dataCount);
  buffer[MSG_INDEX_COUNT_HIGH]     = (unsigned char) (dataCount >> 8);
  buffer[MSG_INDEX_DATA+dataCount] = (unsigned char) 0xff - calcChecksum(buffer, MSG_INDEX_DATA+dataCount);

  if(tcpSocket->isOpen()){
        if(tcpSocket->write(buffer, MSG_HEADER_SIZE+MSG_CHECKSUM_SIZE+dataCount) > 0){
          replyCount = 0;
        }
        tcpSocket->waitForReadyRead(5000);
        length = tcpSocket->read(replyBuffer, MSG_HEADER_SIZE+MSG_CHECKSUM_SIZE+replyCount);

        if(length > 0){
          if(length == MSG_HEADER_SIZE+MSG_CHECKSUM_SIZE+replyCount){
               if ((replyBuffer[MSG_INDEX_START] == buffer[0])                                        &&
                   (replyBuffer[MSG_INDEX_COMMAND] == (buffer[MSG_INDEX_COMMAND] | (char)MSG_REPLY))  &&
                   (replyBuffer[MSG_INDEX_FRAME] == (char)buffer[2])                                  &&
                   (replyBuffer[MSG_INDEX_STATUS] == MSG_SUCCESS)                                     &&
                   (replyBuffer[MSG_INDEX_COUNT_LOW] == ( char) replyCount)                           &&
                   (replyBuffer[MSG_INDEX_COUNT_HIGH] == ( char) (replyCount >> 8)))
               {
                   result = true;
               }

               if(((unsigned char)replyBuffer[MSG_INDEX_DATA+replyCount] + (unsigned char)calcChecksum(replyBuffer, MSG_HEADER_SIZE+replyCount) != 0xff)) {
                 result = false;
               }

           }
         }
         }
 if (result == false) {
   qDebug("Error in BlinkLED_E_TC32. Status = %d\n", replyBuffer[MSG_INDEX_STATUS]);
 }
 return result;
}

/*******************************************************************************
* Class:		mccQEthernet
* Function:		Tin_E_TC32
* Description:	This command reads the value of a single thermocouple channel.
*               There are some special return values:
*
*               -777.0: Input voltage outside valid common-mode voltage range
*               -888.0: Open thermocouple detected
*               -999.0: Channel disabled (also returned if EXP channels are
*                       specified but no EXP is connected)
*               channel: the channel to read (0-63)
*               units:   0 - Celsius, linearized by TC type
*                        1 - Voltage
*                        2 - ADC code (uncalibrated)
*               wait:    0 - return current value, 1 - wait for
*                            new reading before returning
*******************************************************************************/

bool mccQEthernet::Tin_E_TC32()
{

  char buffer[32];
  char replyBuffer[32];
  bool result = false;
  int length;
  int dataCount = 3;
  int replyCount;

  qDebug("FrameID = %d", frameID);

  buffer[MSG_INDEX_COMMAND]        = CMD_TIN;
  buffer[MSG_INDEX_DATA]           = channel;
  //qDebug("Channel is set to %d", channel);
  buffer[MSG_INDEX_DATA+1]         = units;
  //qDebug("Units is set to %d", units);
  buffer[MSG_INDEX_DATA+2]         = wait;
  buffer[MSG_INDEX_START]          = MSG_START;
  buffer[MSG_INDEX_FRAME]          = frameID++;  // increment frame ID with every send
  buffer[MSG_INDEX_STATUS]         = 0;
  buffer[MSG_INDEX_COUNT_LOW]      = (unsigned char) (dataCount);
  buffer[MSG_INDEX_COUNT_HIGH]     = (unsigned char) (dataCount >> 8);
  buffer[MSG_INDEX_DATA+dataCount] = (unsigned char) 0xff - calcChecksum(buffer, MSG_INDEX_DATA+dataCount);

  if(tcpSocket->isOpen()){
       if(tcpSocket->write(buffer, MSG_HEADER_SIZE+MSG_CHECKSUM_SIZE+dataCount) > 0){
         replyCount = 4;
         tcpSocket->waitForReadyRead(5000);
          length = tcpSocket->read(replyBuffer, MSG_HEADER_SIZE+MSG_CHECKSUM_SIZE+replyCount);

		  if(length > 0){
			  //qDebug("length = %d", length);
            if (length == MSG_HEADER_SIZE+MSG_CHECKSUM_SIZE+replyCount) {
			   if ((replyBuffer[MSG_INDEX_START] == buffer[0])                                        &&
				   (replyBuffer[MSG_INDEX_COMMAND] == (buffer[MSG_INDEX_COMMAND] | (char)MSG_REPLY))  &&
				   (replyBuffer[MSG_INDEX_FRAME] == (char)buffer[2])                                  &&
				   (replyBuffer[MSG_INDEX_STATUS] == MSG_SUCCESS)                                     &&
				   (replyBuffer[MSG_INDEX_COUNT_LOW] == ( char) replyCount)                           &&
				   (replyBuffer[MSG_INDEX_COUNT_HIGH] == ( char) (replyCount >> 8)) ){
				 result = true;
			   }
           if (((unsigned char)replyBuffer[MSG_INDEX_DATA+replyCount] + (unsigned char)calcChecksum(replyBuffer, MSG_HEADER_SIZE+replyCount) != 0xff)) {
             result = false;
           }

             }
			else{
				qDebug("Incorrect Length %d received expected %d", length, MSG_HEADER_SIZE+MSG_CHECKSUM_SIZE+replyCount);
			}
         }
       }
         if (result == false) {
           qDebug("Error in Tin_E_TC32. Status = %d\n", replyBuffer[MSG_INDEX_STATUS]);
         }
         else{
             memcpy(&tin_values[channel], &replyBuffer[MSG_INDEX_DATA], 4);
			 //qDebug("Received %f", tin_values[channel]);
         }
		 emit receivedVal(tin_values[channel]);
       }
  else{
    qDebug("TCP Socket not Open! \r\n");
  }
    return result;
}

/*******************************************************************************
* Class:		mccQEthernet
* Function:		TinConfigR_E_TC32
* Description:	This command reads the thermocouple channel configurations.  Each
*               configuration is a uint8_t with the following possible values:
*                    0 - channel disabled
*                    1 - TC type J
*                    2 - TC type K
*                    3 - TC type T
*                    4 - TC type E
*                    5 - TC type R
*                    6 - TC type S
*                    7 - TC type B
*                    8 - TC type N
*******************************************************************************/
bool mccQEthernet::TinConfigR_E_TC32()
{

  char buffer[128];
  char replyBuffer[128];
  bool result = false;
  int length;
  int dataCount = 0;
  int replyCount;

  buffer[MSG_INDEX_COMMAND]        = CMD_TIN_CONFIG_R;
  buffer[MSG_INDEX_START]          = MSG_START;
  buffer[MSG_INDEX_FRAME]          = frameID++;  // increment frame ID with every send
  buffer[MSG_INDEX_STATUS]         = 0;
  buffer[MSG_INDEX_COUNT_LOW]      = (unsigned char) (dataCount);
  buffer[MSG_INDEX_COUNT_HIGH]     = (unsigned char) (dataCount >> 8);
  buffer[MSG_INDEX_DATA+dataCount] = (unsigned char) 0xff - calcChecksum(buffer, MSG_INDEX_DATA+dataCount);

  if(tcpSocket->isOpen()){
      if(tcpSocket->write(buffer, MSG_HEADER_SIZE+MSG_CHECKSUM_SIZE+dataCount) > 0){
        replyCount = 64;

        tcpSocket->waitForReadyRead(5000);
        length = tcpSocket->read(replyBuffer, MSG_HEADER_SIZE+MSG_CHECKSUM_SIZE+replyCount);

        if(length > 0){
          if (length == MSG_HEADER_SIZE+MSG_CHECKSUM_SIZE+replyCount) {
              if ((replyBuffer[MSG_INDEX_START] == buffer[0])                                  &&
                  (replyBuffer[MSG_INDEX_COMMAND] == (buffer[MSG_INDEX_COMMAND] | MSG_REPLY))  &&
                  (replyBuffer[MSG_INDEX_FRAME] == buffer[2])                                  &&
                  (replyBuffer[MSG_INDEX_STATUS] == MSG_SUCCESS)                               &&
                  (replyBuffer[MSG_INDEX_COUNT_LOW] == (unsigned char) replyCount)             &&
                  (replyBuffer[MSG_INDEX_COUNT_HIGH] == (unsigned char) (replyCount >> 8))     &&
                  (replyBuffer[MSG_INDEX_DATA+replyCount] + calcChecksum(replyBuffer, MSG_HEADER_SIZE+replyCount) == 0xff)) {
                result = true;
                memcpy(config_values, &replyBuffer[MSG_INDEX_DATA], 64);
              }
            }
        }
      }
    }

  if (result == false) {
    qDebug("Error in TinConfigR_E_TC32. Status = %d\n", replyBuffer[MSG_INDEX_STATUS]);
  }
  return result;
}

/*******************************************************************************
* Class:		mccQEthernet
* Function:		TinConfigW_E_TC32
* Description:	This command writes the thermocouple channel
                configurations. The micro stores these values in EEPROM and
                loads them from EEPROM at power on.  Each configuration is a
                uint8_t with the following possible values:
                    0 - channel disabled
                    1 - TC type J
                    2 - TC type K
                    3 - TC type T
                    4 - TC type E
                    5 - TC type R
                    6 - TC type S
                    7 - TC type B
                    8 - TC type N
*******************************************************************************/
bool mccQEthernet::TinConfigW_E_TC32()
{

  char buffer[128];
  char replyBuffer[128];
  bool result = false;
  int length;
  int dataCount = 64;
  int replyCount;

  buffer[MSG_INDEX_COMMAND]        = CMD_TIN_CONFIG_W;
  buffer[MSG_INDEX_START]          = MSG_START;
  memcpy(&buffer[MSG_INDEX_DATA], config_values, 64);
  buffer[MSG_INDEX_FRAME]          = frameID++;  // increment frame ID with every send
  buffer[MSG_INDEX_STATUS]         = 0;
  buffer[MSG_INDEX_COUNT_LOW]      = (unsigned char) (dataCount);
  buffer[MSG_INDEX_COUNT_HIGH]     = (unsigned char) (dataCount >> 8);
  buffer[MSG_INDEX_DATA+dataCount] = (unsigned char) 0xff - calcChecksum(buffer, MSG_INDEX_DATA+dataCount);

  if(tcpSocket->isOpen()){
    if(tcpSocket->write(buffer, MSG_HEADER_SIZE+MSG_CHECKSUM_SIZE+dataCount) > 0){
      replyCount = 0;
      tcpSocket->waitForReadyRead(5000);
      length = tcpSocket->read(replyBuffer, MSG_HEADER_SIZE+MSG_CHECKSUM_SIZE+replyCount);

    if(length > 0){
      if (length == MSG_HEADER_SIZE+MSG_CHECKSUM_SIZE+replyCount) {
          if ((replyBuffer[MSG_INDEX_START] == buffer[0])                                        &&
              (replyBuffer[MSG_INDEX_COMMAND] == (buffer[MSG_INDEX_COMMAND] | (char)MSG_REPLY))  &&
              (replyBuffer[MSG_INDEX_FRAME] == (char)buffer[2])                                  &&
              (replyBuffer[MSG_INDEX_STATUS] == MSG_SUCCESS)                                     &&
              (replyBuffer[MSG_INDEX_COUNT_LOW] == (char) replyCount)                            &&
              (replyBuffer[MSG_INDEX_COUNT_HIGH] == (char) (replyCount >> 8))              )
          {
              result = true;
          }
          if((unsigned char)replyBuffer[MSG_INDEX_DATA+replyCount] + (unsigned char)calcChecksum(replyBuffer, MSG_HEADER_SIZE+replyCount) != 0xff) {
            result = false;
          }
        }
      else{
          qDebug("Length not correct! Length is %d", length);
       }
     }
   }
 }

  if (result == false) {
    qDebug("Error in TinConfigW_E_TC32. Status = %d\n", replyBuffer[MSG_INDEX_STATUS]);
  }
  return result;
}

/*******************************************************************************
* Class:		mccQEthernet
* Function:		TinMultiple_E_TC32
* Description:	Ths command reads the value of multiple thermocouple channels.
                The channels to be read are passed as a bitmap when calling the
                command.  The data will be returned in the order low channel
                number to high channel number.  The number of floating point
                values returned will be equal to the number of channels specified
                (max 64).  The special return values listed in the TIn command
                also apply to this command.
                wait:
                    0 - return current value
                    1 - wait for new reading before returning
                units:
                    0 - Celsius
                    1 - Voltage
                    2 - ADC code (uncalibraded)
                channel_mask_base:
                    the channel bitmask for the base unit (channel 0-31)
                channel_mask_exp:
                    the channel bitmask for the EXP unit (channel 32-63)
*******************************************************************************/
bool mccQEthernet::TinMultiple_E_TC32()
{
  char buffer[272];
  char replyBuffer[272];
  bool result = false;
  int length;
  int dataCount = 10;
  int replyCount;

  buffer[MSG_INDEX_COMMAND]        = CMD_TIN_MULTIPLE;
  buffer[MSG_INDEX_DATA]           = wait;
  buffer[MSG_INDEX_DATA+1]         = units;
  memcpy(&buffer[MSG_INDEX_DATA+2], &channel_mask[0], 4);
  memcpy(&buffer[MSG_INDEX_DATA+6], &channel_mask[1], 4);
  buffer[MSG_INDEX_START]          = MSG_START;
  buffer[MSG_INDEX_FRAME]          = frameID++;  // increment frame ID with every send
  buffer[MSG_INDEX_STATUS]         = 0;
  buffer[MSG_INDEX_COUNT_LOW]      = (unsigned char) (dataCount);
  buffer[MSG_INDEX_COUNT_HIGH]     = (unsigned char) (dataCount >> 8);
  buffer[MSG_INDEX_DATA+dataCount] = (unsigned char) 0xff - calcChecksum(buffer, MSG_INDEX_DATA+dataCount);

  if(tcpSocket->isOpen()){
    if(tcpSocket->write(buffer, MSG_HEADER_SIZE+MSG_CHECKSUM_SIZE+dataCount) > 0){
        replyCount = sizeof(float)*(nBits(channel_mask[0]) + nBits(channel_mask[1]));;
        tcpSocket->waitForReadyRead(5000);
        length = tcpSocket->read(replyBuffer, MSG_HEADER_SIZE+MSG_CHECKSUM_SIZE+replyCount);
        if(length > 0){
            if (length == MSG_HEADER_SIZE+MSG_CHECKSUM_SIZE+replyCount) {
                if ((replyBuffer[MSG_INDEX_START] == buffer[0])                                        &&
                    (replyBuffer[MSG_INDEX_COMMAND] == (buffer[MSG_INDEX_COMMAND] | (char)MSG_REPLY))  &&
                    (replyBuffer[MSG_INDEX_FRAME] == (char)buffer[2])                                  &&
                    (replyBuffer[MSG_INDEX_STATUS] == MSG_SUCCESS)                                     &&
                    (replyBuffer[MSG_INDEX_COUNT_LOW] ==  (char) replyCount)                           &&
                    (replyBuffer[MSG_INDEX_COUNT_HIGH] == (char) (replyCount >> 8))                     )
                {
                    result = true;
                }
                if((unsigned char)replyBuffer[MSG_INDEX_DATA+replyCount] + (unsigned char)calcChecksum(replyBuffer, MSG_HEADER_SIZE+replyCount) != 0xff) {
                    result = false;
                }

            }
            else{
                qDebug("Length not correct! Length is %d", length);
            }
        }
     }
  }

  if (result == false) {
    qDebug("Error in TinMultiple_E_TC32. Status = %d\n", replyBuffer[MSG_INDEX_STATUS]);
  }
  else{
      memcpy(tin_values, &replyBuffer[MSG_INDEX_DATA], replyCount);
  }
  emit receivedVals(tin_values);
  return result;
}

/*******************************************************************************
* Class:		mccQEthernet
* Function:		TinStatus_E_TC32
* Description:	This command reads the status of the temperature readings.  If
*               a bit is set the corresponding channel has a new reading that
*               has not been read with either the Tin or TinMultiple command.
*******************************************************************************/
bool mccQEthernet::TinStatus_E_TC32()
{

  char buffer[16];
  char replyBuffer[16];
  bool result = false;
  int length;
  int dataCount = 0;
  int replyCount;

  buffer[MSG_INDEX_COMMAND]        = CMD_TIN_STATUS;
  buffer[MSG_INDEX_START]          = MSG_START;
  buffer[MSG_INDEX_FRAME]          = frameID++;  // increment frame ID with every send
  buffer[MSG_INDEX_STATUS]         = 0;
  buffer[MSG_INDEX_COUNT_LOW]      = (unsigned char) (dataCount);
  buffer[MSG_INDEX_COUNT_HIGH]     = (unsigned char) (dataCount >> 8);
  buffer[MSG_INDEX_DATA+dataCount] = (unsigned char) 0xff - calcChecksum(buffer, MSG_INDEX_DATA+dataCount);

    if(tcpSocket->isOpen()){
      if(tcpSocket->write(buffer, MSG_HEADER_SIZE+MSG_CHECKSUM_SIZE+dataCount) > 0){
        replyCount = 8;
        tcpSocket->waitForReadyRead(5000);
        length = tcpSocket->read(replyBuffer, MSG_HEADER_SIZE+MSG_CHECKSUM_SIZE+replyCount);
        if(length > 0){
            if (length == MSG_HEADER_SIZE+MSG_CHECKSUM_SIZE+replyCount) {
                if ((replyBuffer[MSG_INDEX_START] == buffer[0])                                        &&
                    (replyBuffer[MSG_INDEX_COMMAND] == (buffer[MSG_INDEX_COMMAND] | (char)MSG_REPLY))  &&
                    (replyBuffer[MSG_INDEX_FRAME] == (char)buffer[2])                                  &&
                    (replyBuffer[MSG_INDEX_STATUS] == MSG_SUCCESS)                                     &&
                    (replyBuffer[MSG_INDEX_COUNT_LOW] == (char) replyCount)                            &&
                    (replyBuffer[MSG_INDEX_COUNT_HIGH] == (char) (replyCount >> 8))              )
                {
                    result = true;
                }
                if((unsigned char)replyBuffer[MSG_INDEX_DATA+replyCount] + (unsigned char)calcChecksum(replyBuffer, MSG_HEADER_SIZE+replyCount) != 0xff) {
                    result = false;
                }
            }
            else{
                qDebug("Length not correct! Length is %d", length);
            }
        }
      }
    }
    if (result == false) {
        qDebug("Error in TinStatus_E_TC32. Status = %d\n", replyBuffer[MSG_INDEX_STATUS]);
    }
    else{
        memcpy(Tin_status, &replyBuffer[MSG_INDEX_DATA], 8);
    }
    return result;
}

/*******************************************************************************
* Class:		mccQEthernet
* Function:		Status_E_TC32
* Description:	This command reads the device status.
*               status: bit 0 - no EXP detected, 1 - EXP detected
*******************************************************************************/
bool mccQEthernet::Status_E_TC32()
{

  char buffer[16];
  char replyBuffer[16];
  bool result = false;
  int length;
  int dataCount = 0;
  int replyCount;


  buffer[MSG_INDEX_COMMAND]        = CMD_STATUS;
  buffer[MSG_INDEX_START]          = MSG_START;
  buffer[MSG_INDEX_FRAME]          = frameID++;  // increment frame ID with every send
  buffer[MSG_INDEX_STATUS]         = 0;
  buffer[MSG_INDEX_COUNT_LOW]      = (unsigned char) (dataCount);
  buffer[MSG_INDEX_COUNT_HIGH]     = (unsigned char) (dataCount >> 8);
  buffer[MSG_INDEX_DATA+dataCount] = (unsigned char) 0xff - calcChecksum(buffer, MSG_INDEX_DATA+dataCount);

  if(tcpSocket->isOpen()){
    if(tcpSocket->write(buffer, MSG_HEADER_SIZE+MSG_CHECKSUM_SIZE+dataCount) > 0){
        replyCount = 2;
        tcpSocket->waitForReadyRead(5000);
        length = tcpSocket->read(replyBuffer, MSG_HEADER_SIZE+MSG_CHECKSUM_SIZE+replyCount);

        if(length > 0){
            if (length == MSG_HEADER_SIZE+MSG_CHECKSUM_SIZE+replyCount) {
                if ((replyBuffer[MSG_INDEX_START] == buffer[0])                                        &&
                    (replyBuffer[MSG_INDEX_COMMAND] == (buffer[MSG_INDEX_COMMAND] | (char)MSG_REPLY))  &&
                    (replyBuffer[MSG_INDEX_FRAME] == (char)buffer[2])                                  &&
                    (replyBuffer[MSG_INDEX_STATUS] == MSG_SUCCESS)                                     &&
                    (replyBuffer[MSG_INDEX_COUNT_LOW] ==  (char) replyCount)                           &&
                    (replyBuffer[MSG_INDEX_COUNT_HIGH] == (char) (replyCount >> 8))                     )
                {
                    result = true;
                }
                if((unsigned char)replyBuffer[MSG_INDEX_DATA+replyCount] + (unsigned char)calcChecksum(replyBuffer, MSG_HEADER_SIZE+replyCount) != 0xff) {
                    result = false;
                }
            }
            else{
                qDebug("Length not correct! Length is %d", length);
            }
        }
    }
  }
  if (result == false) {
	qDebug("Error in Status_E_TC32. Status = %d\n", replyBuffer[MSG_INDEX_STATUS]);
  }
  else{
      memcpy(&status, &replyBuffer[MSG_INDEX_DATA], 2);
  }
  return result;
}

/*******************************************************************************
* Class:		mccQEthernet
* Function:		OTDStatus_E_TC32
* Description:	This command reads the status of the open thermocouple
*               detection.  If a bit is set an open thermocouple is currently
*               detected on the corresponding channel.  The LED on the front
*               of the device is on if any bits are set in this value.
*******************************************************************************/
bool mccQEthernet::OTDStatus_E_TC32()
{

  char buffer[16];
  char replyBuffer[16];
  bool result = false;
  int length;
  int dataCount = 0;
  int replyCount;



  buffer[MSG_INDEX_COMMAND]        = CMD_OTD_STATUS;
  buffer[MSG_INDEX_START]          = MSG_START;
  buffer[MSG_INDEX_FRAME]          = frameID++;  // increment frame ID with every send
  buffer[MSG_INDEX_STATUS]         = 0;
  buffer[MSG_INDEX_COUNT_LOW]      = (unsigned char) (dataCount);
  buffer[MSG_INDEX_COUNT_HIGH]     = (unsigned char) (dataCount >> 8);
  buffer[MSG_INDEX_DATA+dataCount] = (unsigned char) 0xff - calcChecksum(buffer, MSG_INDEX_DATA+dataCount);

  if(tcpSocket->isOpen()){
    if(tcpSocket->write(buffer, MSG_HEADER_SIZE+MSG_CHECKSUM_SIZE+dataCount) > 0){
        replyCount = 8;
        tcpSocket->waitForReadyRead(5000);
        length = tcpSocket->read(replyBuffer, MSG_HEADER_SIZE+MSG_CHECKSUM_SIZE+replyCount);

        if(length > 0){
            if (length == MSG_HEADER_SIZE+MSG_CHECKSUM_SIZE+replyCount) {
                if ((replyBuffer[MSG_INDEX_START] == buffer[0])                                        &&
                    (replyBuffer[MSG_INDEX_COMMAND] == (buffer[MSG_INDEX_COMMAND] | (char)MSG_REPLY))  &&
                    (replyBuffer[MSG_INDEX_FRAME] == (char)buffer[2])                                  &&
                    (replyBuffer[MSG_INDEX_STATUS] == MSG_SUCCESS)                                     &&
                    (replyBuffer[MSG_INDEX_COUNT_LOW] ==  (char) replyCount)                           &&
                    (replyBuffer[MSG_INDEX_COUNT_HIGH] == (char) (replyCount >> 8))                     )
                {
                    result = true;
                }
                if((unsigned char)replyBuffer[MSG_INDEX_DATA+replyCount] + (unsigned char)calcChecksum(replyBuffer, MSG_HEADER_SIZE+replyCount) != 0xff) {
                    result = false;
                }
            }
            else{
                qDebug("Length not correct! Length is %d", length);
            }
      }
    }
  }
  if (result == false) {
	qDebug("Error in OTDStatus_E_TC32. Status = %d\n", replyBuffer[MSG_INDEX_STATUS]);
  }
  else{
      memcpy(&OTD_status, &replyBuffer[MSG_INDEX_DATA], 8);
  }
  return result;
}

/*******************************************************************************
* Class:		mccQEthernet
* Function:		Version_E_TC32
* Description:	This command reads the device firmware versions.  Each version
*               will be in hex BCD (i.e. 0x0103 is version 1.03)
*******************************************************************************/
bool mccQEthernet::Version_E_TC32()
{

  char buffer[64];
  char replyBuffer[64];
  bool result = false;
  int length;
  int dataCount = 0;
  int replyCount;

  buffer[MSG_INDEX_COMMAND]        = CMD_VERSION;
  buffer[MSG_INDEX_START]          = MSG_START;
  buffer[MSG_INDEX_FRAME]          = frameID++;  // increment frame ID with every send
  buffer[MSG_INDEX_STATUS]         = 0;
  buffer[MSG_INDEX_COUNT_LOW]      = (unsigned char) (dataCount);
  buffer[MSG_INDEX_COUNT_HIGH]     = (unsigned char) (dataCount >> 8);
  buffer[MSG_INDEX_DATA+dataCount] = (unsigned char) 0xff - calcChecksum(buffer, MSG_INDEX_DATA+dataCount);

  if(tcpSocket->isOpen()){
    if(tcpSocket->write(buffer, MSG_HEADER_SIZE+MSG_CHECKSUM_SIZE+dataCount) > 0){
        replyCount = 12;
        tcpSocket->waitForReadyRead(5000);
        length = tcpSocket->read(replyBuffer, MSG_HEADER_SIZE+MSG_CHECKSUM_SIZE+replyCount);

        if(length > 0){
            if (length == MSG_HEADER_SIZE+MSG_CHECKSUM_SIZE+replyCount) {
                if ((replyBuffer[MSG_INDEX_START] == buffer[0])                                        &&
                    (replyBuffer[MSG_INDEX_COMMAND] == (buffer[MSG_INDEX_COMMAND] | (char)MSG_REPLY))  &&
                    (replyBuffer[MSG_INDEX_FRAME] == (char)buffer[2])                                  &&
                    (replyBuffer[MSG_INDEX_STATUS] == MSG_SUCCESS)                                     &&
                    (replyBuffer[MSG_INDEX_COUNT_LOW] ==  (char) replyCount)                           &&
                    (replyBuffer[MSG_INDEX_COUNT_HIGH] == (char) (replyCount >> 8))                     )
                {
                    result = true;
                }
                if((unsigned char)replyBuffer[MSG_INDEX_DATA+replyCount] + (unsigned char)calcChecksum(replyBuffer, MSG_HEADER_SIZE+replyCount) != 0xff) {
                    result = false;
                }
            }
            else{
                qDebug("Length not correct! Length is %d", length);
            }
        }
    }
  }

  if (result == false) {
	qDebug("Error in Version_E_TC32. Status = %d\n", replyBuffer[MSG_INDEX_STATUS]);
  }
  else{
      memcpy(&version, &replyBuffer[MSG_INDEX_DATA], 12);
  }
  return result;
}

/*******************************************************************************
* Class:		mccQEthernet
* Function:		CalDateR_E_TC32
* Description:	This command reads the calibration dates.
*******************************************************************************/
bool mccQEthernet::CalDateR_E_TC32()
{

  char buffer[32];
  char replyBuffer[32];
  bool result = false;
  int length;
  int dataCount = 0;
  int replyCount;
  time_t time;



  buffer[MSG_INDEX_COMMAND]        = CMD_CAL_DATE_R;
  buffer[MSG_INDEX_START]          = MSG_START;
  buffer[MSG_INDEX_FRAME]          = frameID++;  // increment frame ID with every send
  buffer[MSG_INDEX_STATUS]         = 0;
  buffer[MSG_INDEX_COUNT_LOW]      = (unsigned char) (dataCount);
  buffer[MSG_INDEX_COUNT_HIGH]     = (unsigned char) (dataCount >> 8);
  buffer[MSG_INDEX_DATA+dataCount] = (unsigned char) 0xff - calcChecksum(buffer, MSG_INDEX_DATA+dataCount);

  if(tcpSocket->isOpen()){
    if(tcpSocket->write(buffer, MSG_HEADER_SIZE+MSG_CHECKSUM_SIZE+dataCount) > 0){
        replyCount = 12;
        tcpSocket->waitForReadyRead(5000);
        length = tcpSocket->read(replyBuffer, MSG_HEADER_SIZE+MSG_CHECKSUM_SIZE+replyCount);

        if(length > 0){
            if (length == MSG_HEADER_SIZE+MSG_CHECKSUM_SIZE+replyCount) {
                if ((replyBuffer[MSG_INDEX_START] == buffer[0])                                        &&
                    (replyBuffer[MSG_INDEX_COMMAND] == (buffer[MSG_INDEX_COMMAND] | (char)MSG_REPLY))  &&
                    (replyBuffer[MSG_INDEX_FRAME] == (char)buffer[2])                                  &&
                    (replyBuffer[MSG_INDEX_STATUS] == MSG_SUCCESS)                                     &&
                    (replyBuffer[MSG_INDEX_COUNT_LOW] ==  (char) replyCount)                           &&
                    (replyBuffer[MSG_INDEX_COUNT_HIGH] == (char) (replyCount >> 8))                     )
                {
                    result = true;
                }
                if((unsigned char)replyBuffer[MSG_INDEX_DATA+replyCount] + (unsigned char)calcChecksum(replyBuffer, MSG_HEADER_SIZE+replyCount) != 0xff) {
                    result = false;
                }
           }
           else{
                qDebug("Length not correct! Length is %d", length);
           }
       }
    }
  }
  if (result == false) {
	qDebug("Error in CalDateR_E_TC32. Status = %d\n", replyBuffer[MSG_INDEX_STATUS]);
  }
  else{

      date_base.tm_year = replyBuffer[MSG_INDEX_DATA] + 100;
      date_base.tm_mon = replyBuffer[MSG_INDEX_DATA+1] - 1;
      date_base.tm_mday = replyBuffer[MSG_INDEX_DATA+2];
      date_base.tm_hour = replyBuffer[MSG_INDEX_DATA+3];
      date_base.tm_min = replyBuffer[MSG_INDEX_DATA+4];
      date_base.tm_sec = replyBuffer[MSG_INDEX_DATA+5];
      time = mktime(&date_base);
      date_base = *localtime(&time);

      date_exp.tm_year = replyBuffer[MSG_INDEX_DATA+6] + 100;
      date_exp.tm_mon = replyBuffer[MSG_INDEX_DATA+7] - 1;
      date_exp.tm_mday = replyBuffer[MSG_INDEX_DATA+8];
      date_exp.tm_hour = replyBuffer[MSG_INDEX_DATA+9];
      date_exp.tm_min = replyBuffer[MSG_INDEX_DATA+10];
      date_exp.tm_sec = replyBuffer[MSG_INDEX_DATA+11];
      time = mktime(&date_exp);
      date_exp = *localtime(&time);
    }

  return result;
}

/*******************************************************************************
* Class:		mccQEthernet
* Function:		CJC_E_TC32
* Description:	This command reads the most recent value of a single CJC sensor
*               in Celsius.  The value -999.0 will be returned if an EXP sensor
*               is specified bu no EXP is connected.
*               special return values:
*                    channel: the channel to read (0-63)
*******************************************************************************/
bool mccQEthernet::CJC_E_TC32(uint8_t channel, float *value)
{
  char buffer[32];
  char replyBuffer[32];
  bool result = false;
  int length;
  int dataCount = 1;
  int replyCount;

  buffer[MSG_INDEX_COMMAND]        = CMD_CJC;
  buffer[MSG_INDEX_DATA]           = channel;
  buffer[MSG_INDEX_START]          = MSG_START;
  buffer[MSG_INDEX_FRAME]          = frameID++;  // increment frame ID with every send
  buffer[MSG_INDEX_STATUS]         = 0;
  buffer[MSG_INDEX_COUNT_LOW]      = (unsigned char) (dataCount);
  buffer[MSG_INDEX_COUNT_HIGH]     = (unsigned char) (dataCount >> 8);
  buffer[MSG_INDEX_DATA+dataCount] = (unsigned char) 0xff - calcChecksum(buffer, MSG_INDEX_DATA+dataCount);

  if(tcpSocket->isOpen()){
    if(tcpSocket->write(buffer, MSG_HEADER_SIZE+MSG_CHECKSUM_SIZE+dataCount) > 0){
        replyCount = 4;
        tcpSocket->waitForReadyRead(5000);
        length = tcpSocket->read(replyBuffer, MSG_HEADER_SIZE+MSG_CHECKSUM_SIZE+replyCount);

        if(length > 0){
            if (length == MSG_HEADER_SIZE+MSG_CHECKSUM_SIZE+replyCount) {
                if ((replyBuffer[MSG_INDEX_START] == buffer[0])                                        &&
                    (replyBuffer[MSG_INDEX_COMMAND] == (buffer[MSG_INDEX_COMMAND] | (char)MSG_REPLY))  &&
                    (replyBuffer[MSG_INDEX_FRAME] == (char)buffer[2])                                  &&
                    (replyBuffer[MSG_INDEX_STATUS] == MSG_SUCCESS)                                     &&
                    (replyBuffer[MSG_INDEX_COUNT_LOW] ==  (char) replyCount)                           &&
                    (replyBuffer[MSG_INDEX_COUNT_HIGH] == (char) (replyCount >> 8))                     )
                {
                    result = true;
                }
                if((unsigned char)replyBuffer[MSG_INDEX_DATA+replyCount] + (unsigned char)calcChecksum(replyBuffer, MSG_HEADER_SIZE+replyCount) != 0xff) {
                    result = false;
                }
            }
            else{
                qDebug("Length not correct! Length is %d", length);
            }
      }
    }
  }
  if (result == false) {
    qDebug("Error in CJC_E_TC32. Status = %d\n", replyBuffer[MSG_INDEX_STATUS]);
  }
  else{
      memcpy(value, &replyBuffer[MSG_INDEX_DATA], 4);
  }
  return result;
}

/*******************************************************************************
* Class:		mccQEthernet
* Function:		NetworkConfig_E_TC32
* Description:	This command reads the current device network configuration
*******************************************************************************/
bool mccQEthernet::NetworkConfig_E_TC32()
{

  char buffer[64];
  char replyBuffer[64];
  bool result = false;
  int length;
  int dataCount = 0;
  int replyCount;

  buffer[MSG_INDEX_COMMAND]        = CMD_NETWORK_CONFIG;
  buffer[MSG_INDEX_START]          = MSG_START;
  buffer[MSG_INDEX_FRAME]          = frameID++;  // increment frame ID with every send
  buffer[MSG_INDEX_STATUS]         = 0;
  buffer[MSG_INDEX_COUNT_LOW]      = (unsigned char) (dataCount);
  buffer[MSG_INDEX_COUNT_HIGH]     = (unsigned char) (dataCount >> 8);
  buffer[MSG_INDEX_DATA+dataCount] = (unsigned char) 0xff - calcChecksum(buffer, MSG_INDEX_DATA+dataCount);

  if(tcpSocket->isOpen()){
    if(tcpSocket->write(buffer, MSG_HEADER_SIZE+MSG_CHECKSUM_SIZE+dataCount) > 0){
        replyCount = 12;
        tcpSocket->waitForReadyRead(5000);
        length = tcpSocket->read(replyBuffer, MSG_HEADER_SIZE+MSG_CHECKSUM_SIZE+replyCount);

        if(length > 0){
            if (length == MSG_HEADER_SIZE+MSG_CHECKSUM_SIZE+replyCount) {
                if ((replyBuffer[MSG_INDEX_START] == buffer[0])                                        &&
                    (replyBuffer[MSG_INDEX_COMMAND] == (buffer[MSG_INDEX_COMMAND] | (char)MSG_REPLY))  &&
                    (replyBuffer[MSG_INDEX_FRAME] == (char)buffer[2])                                  &&
                    (replyBuffer[MSG_INDEX_STATUS] == MSG_SUCCESS)                                     &&
                    (replyBuffer[MSG_INDEX_COUNT_LOW] ==  (char) replyCount)                           &&
                    (replyBuffer[MSG_INDEX_COUNT_HIGH] == (char) (replyCount >> 8))                     )
                {
                    result = true;
                }
                if((unsigned char)replyBuffer[MSG_INDEX_DATA+replyCount] + (unsigned char)calcChecksum(replyBuffer, MSG_HEADER_SIZE+replyCount) != 0xff) {
                    result = false;
                }
            }
            else{
                qDebug("Length not correct! Length is %d", length);
            }
       }
    }
  }
  if (result == false) {
	qDebug("Error in NetworkConfig_E_TC32. Status = %d\n", replyBuffer[MSG_INDEX_STATUS]);
  }
  else{
      memcpy(&netDevInfo, &replyBuffer[MSG_INDEX_DATA], 12);
  }
  return result;
}


/*******************************************************************************
* Class:		mccQEthernet
* Function:		ADCal_E_TC32
* Description:	This command causes the measurement loop to pause and an A/D
*               system offset calibration to run.  The calibration requires
*               approximately 50ms to complete then the measurement loop
*               automatically returns to the current mode.  The calibration will
*               run on all A/Ds on both the main unit and EXP simultaneously.
*               The command reply will not be sent until the calibration
*               completes.
*******************************************************************************/
bool mccQEthernet::ADCal_E_TC32()
{

  char buffer[16];
  char replyBuffer[16];
  bool result = false;
  int length;
  int dataCount = 0;
  int replyCount;

  buffer[MSG_INDEX_COMMAND]        = CMD_AD_CAL;
  buffer[MSG_INDEX_START]          = MSG_START;
  buffer[MSG_INDEX_FRAME]          = frameID++;  // increment frame ID with every send
  buffer[MSG_INDEX_STATUS]         = 0;
  buffer[MSG_INDEX_COUNT_LOW]      = (unsigned char) (dataCount);
  buffer[MSG_INDEX_COUNT_HIGH]     = (unsigned char) (dataCount >> 8);
  buffer[MSG_INDEX_DATA+dataCount] = (unsigned char) 0xff - calcChecksum(buffer, MSG_INDEX_DATA+dataCount);

  if(tcpSocket->isOpen()){
    if(tcpSocket->write(buffer, MSG_HEADER_SIZE+MSG_CHECKSUM_SIZE+dataCount) > 0){
        replyCount = 0;
        tcpSocket->waitForReadyRead(5000);
        length = tcpSocket->read(replyBuffer, MSG_HEADER_SIZE+MSG_CHECKSUM_SIZE+replyCount);

        if(length > 0){
            if (length == MSG_HEADER_SIZE+MSG_CHECKSUM_SIZE+replyCount) {
                if ((replyBuffer[MSG_INDEX_START] == buffer[0])                                        &&
                    (replyBuffer[MSG_INDEX_COMMAND] == (buffer[MSG_INDEX_COMMAND] | (char)MSG_REPLY))  &&
                    (replyBuffer[MSG_INDEX_FRAME] == (char)buffer[2])                                  &&
                    (replyBuffer[MSG_INDEX_STATUS] == MSG_SUCCESS)                                     &&
                    (replyBuffer[MSG_INDEX_COUNT_LOW] ==  (char) replyCount)                           &&
                    (replyBuffer[MSG_INDEX_COUNT_HIGH] == (char) (replyCount >> 8))                     )
                {
                    result = true;
                }
                if((unsigned char)replyBuffer[MSG_INDEX_DATA+replyCount] + (unsigned char)calcChecksum(replyBuffer, MSG_HEADER_SIZE+replyCount) != 0xff) {
                    result = false;
                }
           }
           else{
              qDebug("Length not correct! Length is %d", length);
           }
       }
   }
  }
  return result;
}

/*******************************************************************************
* Class:		mccQEthernet
* Function:		SettingsMemoryR_E_TC32
* Description:	This command reads the nonvolatile network memory. The
*               settings memory is 32 bytes (address 0 - 0x1F).
*******************************************************************************/
bool mccQEthernet::SettingsMemoryR_E_TC32(uint16_t address, uint16_t count, uint8_t *data)
{
  char buffer[64];
  char replyBuffer[64];
  bool result = false;
  int length;
  int dataCount = 4;
  int replyCount;


  if (address > 0x1F) {
	 qDebug("SettingsMemoryR_E_TC32: max value of address is 0x1F.\n");
    return false;
  }
  if (count > 32) {
	 qDebug("SettingsMemoryR_E_TC32: max value of count is 32\n");
    return false;
  }

  buffer[MSG_INDEX_COMMAND]        = CMD_SETTINGS_MEMORY_R;
  buffer[MSG_INDEX_START]          = MSG_START;
  memcpy(&buffer[MSG_INDEX_DATA], &address, 2);
  memcpy(&buffer[MSG_INDEX_DATA+2], &count, 2);
  buffer[MSG_INDEX_FRAME]          = frameID++;  // increment frame ID with every send
  buffer[MSG_INDEX_STATUS]         = 0;
  buffer[MSG_INDEX_COUNT_LOW]      = (unsigned char) (dataCount);
  buffer[MSG_INDEX_COUNT_HIGH]     = (unsigned char) (dataCount >> 8);
  buffer[MSG_INDEX_DATA+dataCount] = (unsigned char) 0xff - calcChecksum(buffer, MSG_INDEX_DATA+dataCount);

  if(tcpSocket->isOpen()){
    if(tcpSocket->write(buffer, MSG_HEADER_SIZE+MSG_CHECKSUM_SIZE+dataCount) > 0){
        replyCount = count;
        tcpSocket->waitForReadyRead(5000);
        length = tcpSocket->read(replyBuffer, MSG_HEADER_SIZE+MSG_CHECKSUM_SIZE+replyCount);

        if(length > 0){
            if (length == MSG_HEADER_SIZE+MSG_CHECKSUM_SIZE+replyCount) {
                if ((replyBuffer[MSG_INDEX_START] == buffer[0])                                        &&
                    (replyBuffer[MSG_INDEX_COMMAND] == (buffer[MSG_INDEX_COMMAND] | (char)MSG_REPLY))  &&
                    (replyBuffer[MSG_INDEX_FRAME] == (char)buffer[2])                                  &&
                    (replyBuffer[MSG_INDEX_STATUS] == MSG_SUCCESS)                                     &&
                    (replyBuffer[MSG_INDEX_COUNT_LOW] ==  (char) replyCount)                           &&
                    (replyBuffer[MSG_INDEX_COUNT_HIGH] == (char) (replyCount >> 8))                     )
                {
                    result = true;
                }
                if((unsigned char)replyBuffer[MSG_INDEX_DATA+replyCount] + (unsigned char)calcChecksum(replyBuffer, MSG_HEADER_SIZE+replyCount) != 0xff)
                {
                    result = false;
                }
            }
            else{
                qDebug("Length not correct! Length is %d", length);
            }
       }
    }
  }
  if (result == false) {
	 qDebug("Error in SettingsMemoryR_E_TC32. Status = %d\n", replyBuffer[MSG_INDEX_STATUS]);
  }
  else{
      memcpy(data, &replyBuffer[MSG_INDEX_DATA], count);
  }
  return result;
}

/*******************************************************************************
* Class:		mccQEthernet
* Function:		SettingsMemoryW_E_TC32
* Description:	This command writes the nonvolatile settings memory. The settings
*               memory is 32 bytes (address 0 - 0x1F).  The amount of data to be
*               written is inferred from the frame count - 2.  The maximum that
*               can be written is 32 bytes.  The settings will be implemented
*               after a device reset.
*******************************************************************************/
bool mccQEthernet::SettingsMemoryW_E_TC32( uint16_t address, uint16_t count, uint8_t *data)
{
  char buffer[64];
  char replyBuffer[64];
  bool result = false;
  int length;
  int dataCount = count+2;
  int replyCount;

  if (address > 0x1F) {
	 qDebug("SettingsMemoryW_E_TC32: max value of address is 0x1F.\n");
    return false;
  }

  if (count > 32) {
	 qDebug("SettingsMemoryW_E_TC32: max value of count is 0x32.\n");
    return false;
  }

  buffer[MSG_INDEX_COMMAND]        = CMD_SETTINGS_MEMORY_W;
  buffer[MSG_INDEX_START]          = MSG_START;
  memcpy(&buffer[MSG_INDEX_DATA], &address, 2);
  memcpy(&buffer[MSG_INDEX_DATA+2], data, count);
  buffer[MSG_INDEX_FRAME]          = frameID++;  // increment frame ID with every send
  buffer[MSG_INDEX_STATUS]         = 0;
  buffer[MSG_INDEX_COUNT_LOW]      = (unsigned char) (dataCount);
  buffer[MSG_INDEX_COUNT_HIGH]     = (unsigned char) (dataCount >> 8);
  buffer[MSG_INDEX_DATA+dataCount] = (unsigned char) 0xff - calcChecksum(buffer, MSG_INDEX_DATA+dataCount);

  if(tcpSocket->isOpen()){
    if(tcpSocket->write(buffer, MSG_HEADER_SIZE+MSG_CHECKSUM_SIZE+dataCount) > 0){
        replyCount = 0;
        tcpSocket->waitForReadyRead(5000);
        length = tcpSocket->read(replyBuffer, MSG_HEADER_SIZE+MSG_CHECKSUM_SIZE+replyCount);

        if(length > 0){
            if (length == MSG_HEADER_SIZE+MSG_CHECKSUM_SIZE+replyCount) {
                if ((replyBuffer[MSG_INDEX_START] == buffer[0])                                        &&
                    (replyBuffer[MSG_INDEX_COMMAND] == (buffer[MSG_INDEX_COMMAND] | (char)MSG_REPLY))  &&
                    (replyBuffer[MSG_INDEX_FRAME] == (char)buffer[2])                                  &&
                    (replyBuffer[MSG_INDEX_STATUS] == MSG_SUCCESS)                                     &&
                    (replyBuffer[MSG_INDEX_COUNT_LOW] ==  (char) replyCount)                           &&
                    (replyBuffer[MSG_INDEX_COUNT_HIGH] == (char) (replyCount >> 8))                     )
                {
                    result = true;
                }
            if((unsigned char)replyBuffer[MSG_INDEX_DATA+replyCount] + (unsigned char)calcChecksum(replyBuffer, MSG_HEADER_SIZE+replyCount) != 0xff) {
                result = false;
            }
          }
        else{
            qDebug("Length not correct! Length is %d", length);
        }
      }
    }
  }

  if (result == false) {
	qDebug("Error in SettingsMemoryW_E_TC32. Status = %d\n", replyBuffer[MSG_INDEX_STATUS]);
  }
  return result;
}

/*******************************************************************************
* Class:		mccQEthernet
* Function:		startPollTimer
* Description:	This command configures and starts the event timer for automated
*               capture of a single channel.
*******************************************************************************/
void mccQEthernet::startPollTimer(quint32 timeoutmS, quint8 wait4newSamp, quint8 tcType[64], quint8 units_type, quint32 capCh_mask){

	qDebug("Starting Timer \r\n");
	eventTimer = new QTimer(this);
	eventTimer->setTimerType(Qt::PreciseTimer);
	eventTimer->setInterval(timeoutmS);

	wait = wait4newSamp;
	for (int i = 0; i< 64; i++) {
		config_values[i] = 0x0;   // disable all channels
	}
	for (int i = 0; i < 32; i++) {
		config_values[i] = tcType[i];
	}
	TinConfigW_E_TC32();
	units = units_type;
	channel_mask[0] = capCh_mask;
	timeoutInterval = timeoutmS;
	connect(eventTimer, SIGNAL(timeout(void)), this, SLOT(TinMultiple_E_TC32(void)));

    eventTimer->start();
    timrAct = 1;
}
