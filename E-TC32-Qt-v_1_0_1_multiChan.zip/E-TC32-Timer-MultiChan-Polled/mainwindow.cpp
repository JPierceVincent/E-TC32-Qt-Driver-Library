/************************************************************************************************
 * File:			mainwindow.cpp
 * Author:			Joseph Vincent
 * Email:			josephpiercevincent@gmail.com
 * Github:          https://github.com/JPierceVincent
 * Based On:        E-TC32 Example
 * Author:          Warren J. Jasper
 * Email:           wjasper@ncsu.edu
 * Github:          https://github.com/wjasper
 *
 * Create Date:		February 2nd, 2021, 15:57 PM
 * Module Name:		Main Window
 * Target Devices:	Windows 10 or Linux
 * Tool versions:	Qt 5.13.0
 * Complier:		MinGW 4.8 32bit
 * Description:		This is example demonstrates single channel data acquisition from the
 *                  MCC TC-32 using an internal event QTimer in the mccqethernet object and
 *                  signals and slots.
 *~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*/
#include "mainwindow.h"
#include "ui_mainwindow.h"
#include <QDebug>
#include <QThread>
#include <QMetaType>

MainWindow::MainWindow(QWidget *parent) :
	QMainWindow(parent),
	ui(new Ui::MainWindow)
{
	ui->setupUi(this);
	char uiLabel[32];
	QLCDNumber* qbptr;
	for (int i=0; i<32; i++){
		sprintf(uiLabel,"tctemp%d",i+1);
		qbptr = ui->gridLayoutWidget->findChild<QLCDNumber *>(QString::fromLocal8Bit(uiLabel)) ;
		qbptr->setDigitCount(5);
		qbptr->setPalette(Qt::black);

	}
//	ui->tctemp->setDigitCount(5);
//	ui->tctemp->setPalette(Qt::black);

	QThread::currentThread()->setObjectName("GUI_Thread");

	tc32thread = new QThread;
	TC32 = new mccQEthernet;
	TC32->moveToThread(tc32thread);
	connect(TC32, SIGNAL(destroyed()), tc32thread, SLOT(quit()));
	connect(this, SIGNAL(destroyed()), TC32, SLOT(deleteLater()));
	connect(this, SIGNAL(connectTc32(quint32, QString)), TC32, SLOT(openDevice(quint32, QString)));
	connect(TC32, SIGNAL(connFin(int)), this, SLOT(TC32_Connection_Finished(int)));
	connect(this, SIGNAL(startCapTimer(quint32, quint8, quint8*, quint8, quint32)), TC32, SLOT(startPollTimer(quint32, quint8, quint8*, quint8, quint32)));
	connect(TC32, SIGNAL(receivedVals(float *)), this, SLOT(updateTempDisp(float *)));
	tc32thread->start();
	emit connectTc32(TC32_CONNECTION_CODE, TC32_IP_ADDRESS);
}


MainWindow::~MainWindow()
{

   // delete TC32;
	delete ui;
}
/*******************************************************************************
* Class:		mainWindow
* SLOT:         TC32 Connection Finished
* Description:	Receives the emitted signal after TCP connection has been
*				attempted by mccQEthernet Device. A Successful connection returns
*				a status of 1 and an unsuccesful connection returns -1
*******************************************************************************/
void MainWindow::TC32_Connection_Finished(int status)
{

	if ((status < 0)) {
		ui->etcStat->setText("TC32 Status: Error OpenSock");
	  qDebug("Error opening socket");
	}
	else{
		for(int i = 0; i < 32; i++){
			config_values[i] = TC_TYPE_K;
		}
		channel_mask = 0xFFFFFFFF; //All 32 Channels
		ui->etcStat->setText("TC32 Status: Connected");
		//Start Event Timer
		emit startCapTimer(5000, 1, config_values, UNITS_CELSIUS, channel_mask); // Timeout interval in mS | Wait for new Sample | ThermoCouple Type | Cap Channel
	}

}

/*******************************************************************************
* Class:		mainWindow
* SLOT:         updateTempDisp
* Description:	Receives the emitted signal after a sample has been acquired from
*               a channel and prints the channel and its value.
*******************************************************************************/
void MainWindow::updateTempDisp(float value[64])
{

	char uiLabel[32];
	QLCDNumber* qbptr;

	for (int i=0; i<32; i++){
		sprintf(uiLabel,"tctemp%d",i+1);
		qbptr = ui->gridLayoutWidget->findChild<QLCDNumber *>(QString::fromLocal8Bit(uiLabel)) ;
		qbptr->display(value[i]);
	}
	//qDebug("New Temp Val %f", value);
}
