#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include "mccqethernet.h"

namespace Ui {
class MainWindow;
}

#define TC32_CONNECTION_CODE 1064
#define TC32_IP_ADDRESS "10.220.162.69"

class MainWindow : public QMainWindow
{
		Q_OBJECT

	public:

		float temperature;
		explicit MainWindow(QWidget *parent = nullptr);
		~MainWindow();

	public slots:
        void updateTempDisp(int channel);

	private:
		Ui::MainWindow *ui;
		QThread *tc32thread;
		mccQEthernet *TC32;
};

#endif // MAINWINDOW_H
