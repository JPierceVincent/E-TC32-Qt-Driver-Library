/************************************************************************************************
 * File:			mainwindow.cpp
 * Author:			Joseph Vincent
 * Email:			josephpiercevincent@gmail.com
 * Github:          https://github.com/JPierceVincent
 * Based On:        E-TC32 Example
 * Author:          Warren J. Jasper
 * Email:           wjasper@ncsu.edu
 * Github:          https://github.com/wjasper
 *
 * Create Date:		February 2nd, 2021, 15:57 PM
 * Module Name:		Main Window
 * Target Devices:	Windows 10 or Linux
 * Tool versions:	Qt 5.13.0
 * Complier:		MinGW 4.8 32bit
 * Description:		This is example demonstrates single channel data acquisition from the
 *                  MCC TC-32 using an internal event QTimer in the mccqethernet object and
 *                  signals and slots.
 *~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*/
#include "mainwindow.h"
#include "ui_mainwindow.h"
#include <QDebug>
#include <QThread>

MainWindow::MainWindow(QWidget *parent) :
	QMainWindow(parent),
	ui(new Ui::MainWindow)
{
	ui->setupUi(this);

	QThread::currentThread()->setObjectName("GUI_Thread");

	tc32thread = new QThread;
	TC32 = new mccQEthernet;
	TC32->moveToThread(tc32thread);
	//Set up TC32
    TC32->frameID = 0; //Initialize frameID to 0 for TC32 message allignment
	TC32->connectionCode = TC32_CONNECTION_CODE;
	 // qDebug("Opening Socket for E-TC32 IP address: " + TC32_IP_ADDRESS);
    TC32->netDevInfo.addr = TC32_IP_ADDRESS;
    if ((TC32->openDevice() < 0)) {
	  qDebug("Error opening socket");
	}
    else{	// Connected --> Set up cap settings and start timer
        TC32->wait = 0x1;
		for (int i = 0; i< 64; i++) {
		  TC32->config_values[i] = 0x0;   // disable all channels
		}
		TC32->config_values[0] = TC_TYPE_K; // Set desired channel(s) to appropriate thermocouple type (CH0 -> K in this case)
		TC32->TinConfigW_E_TC32();	// Reconfigure Hardware to these settings
        connect(TC32, SIGNAL(receivedVal(int channel)), this, SLOT(updateTempDisp(int channel)));
        TC32->timerOpt = 0; // set for single channel capture
        TC32->timeoutInterval = 5000; // Set timeout interval in mS
        TC32->startPollTimer(); //configure and start the QTimer
	}

}

MainWindow::~MainWindow()
{
    delete TC32;
	delete ui;
}

/*******************************************************************************
* Class:		mainWindow
* SLOT:         updateTempDisp
* Description:	Receives the emitted signal after a sample has been acquired from
*               a channel and prints the channel and its value.
*******************************************************************************/
void MainWindow::updateTempDisp(int channel)
{
    qDebug("New Temp CH %d Val %f", channel, TC32->tin_values[channel]);
}
